--require("settings")
require("prototypes.armor")
require("prototypes.modified-equipment-grid")