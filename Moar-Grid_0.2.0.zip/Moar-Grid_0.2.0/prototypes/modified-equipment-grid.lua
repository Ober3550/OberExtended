data:extend({
{
type = "equipment-grid",
name = "modified-equipment-grid-mk2",
width = settings.startup["moar-grid-width"].value,--36,
height = settings.startup["moar-grid-height"].value,--10,
equipment_categories = {"armor"}
},
})