data:extend({
    {
    type = "item",
    name = "rocket-component",
    icon = "__base__/graphics/icons/rocket-part.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    subgroup = "intermediate-product",
    order = "a[rocket-component]",
    stack_size = 100
    },
    {
    type = "item",
    name = "assembled-rocket",
    icon = "__OberRocketry__/graphics/rocket-item.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    subgroup = "intermediate-product",
    order = "a[rocket-component]",
    stack_size = 1,
    rocket_launch_product = {"space-science-pack", 1000}
    },      
    {
    type = "recipe",
    name = "rocket-component",
    energy_required = 3,
    enabled = true,
    category = "crafting",
    ingredients =
    {
      {"rocket-control-unit", 10},
      {"low-density-structure", 10},
      {"rocket-fuel", 10}
    },
    result= "rocket-component"
    },
    {
    type = "recipe",
    name = "assembled-rocket",
    energy_required = 0.5,
    enabled = true,
    category = "crafting",
    ingredients =
    {
      {"rocket-component", 100},
      {"satellite",1}
    },
    result= "assembled-rocket"
    },
})

function allow_productivity(recipe_name)
  for _, prototype in pairs(data.raw["module"]) do
    if prototype.limitation and string.find(prototype.name, "productivity", 1, true) then
      table.insert(prototype.limitation, recipe_name)
    end
  end
end

allow_productivity("rocket-component")

data.raw["item"]["satellite"].rocket_launch_product = nil
data.raw["rocket-silo"]["rocket-silo"].fixed_recipe = "rocket-part"
data.raw["rocket-silo"]["rocket-silo"].rocket_parts_required = 1
data.raw["rocket-silo"]["rocket-silo"].hide_alt_info = true

data.raw["rocket-silo"]["rocket-silo"].rocket_result_inventory_size = 2
local rocket_fluid_box = 
    {
    production_type="input", 
    pipe_covers = pipecoverspictures(), 
    base_level = -1, 
    pipe_connections = {{position={0,5.5}}},
    }
data.raw["rocket-silo"]["rocket-silo"].fluid_boxes =  {rocket_fluid_box}
data.raw.recipe["rocket-part"].ingredients = {{type="fluid",name="light-oil",amount=100}}
data.raw["ammo"]["rocket"].rocket_launch_product = {"space-science-pack", 1 }
data.raw["ammo"]["artillery-shell"].rocket_launch_product = {"space-science-pack", 10 }
--[[
data:extend({
    {
    type = "recipe",
    name = "hobyist-rocket",
    energy_required = 60,
    enabled = false,
    hidden = true,
    category = "rocket-building",
    ingredients =
    {
      {"pipe", 10},
      {"solid-fuel", 10},
      {"iron-plate", 10}
    },
    result= "rocket-part"
    },
    {
    type = "recipe",
    name = "small-solid-fuel-rocket",
    energy_required = 3,
    enabled = false,
    hidden = true,
    category = "rocket-building",
    ingredients =
    {
      {"engine-unit", 1},
      {"solid-fuel", 1},
      {"payload", 1}
    },
    result= "rocket-part"
    },
    {
    type = "recipe",
    name = "medium-solid-fuel-rocket",
    energy_required = 3,
    enabled = false,
    hidden = true,
    category = "rocket-building",
    ingredients =
    {
      {"pipe", 1},
      {"solid-fuel", 1},
      {"payload", 1}
    },
    result= "rocket-part"
    },
    {
    type = "recipe",
    name = "large-solid-fuel-rocket",
    energy_required = 3,
    enabled = false,
    hidden = true,
    category = "rocket-building",
    ingredients =
    {
      {"pipe", 1},
      {"solid-fuel", 1},
      {"payload", 1}
    },
    result= "rocket-part"
    },
    {
    type = "recipe",
    name = "medium-liquid-fuel-rocket",
    energy_required = 3,
    enabled = false,
    hidden = true,
    category = "rocket-building",
    ingredients =
    {
      {"pipe", 1},
      {"solid-fuel", 1},
      {"payload", 1}
    },
    result= "rocket-part"
    },
    {
    type = "recipe",
    name = "large-liquid-fuel-rocket",
    energy_required = 3,
    enabled = false,
    hidden = true,
    category = "rocket-building",
    ingredients =
    {
      {"pipe", 1},
      {"solid-fuel", 1},
      {"payload", 1}
    },
    result= "rocket-part"
    },
    {
    type = "recipe",
    name = "BFR",
    energy_required = 3,
    enabled = false,
    hidden = true,
    category = "rocket-building",
    ingredients =
    {
      {"pipe", 1},
      {"solid-fuel", 1},
      {"payload", 1}
    },
    result= "rocket-part"
    },
})--]]