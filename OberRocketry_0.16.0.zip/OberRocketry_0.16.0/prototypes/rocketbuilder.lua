data:extend({
    {
    type = "item-group",
    name = "space-exploration",
    order = "x",
    inventory_order = "x",
    icon = "__OberRocketry__/graphics/rocket-tab.png",
    icon_size = 64,
    },
    {
    type = "item-subgroup",
    name = "space-exploration-a",
    group = "space-exploration",
    order = "a",
    },
    {
    type = "item-subgroup",
    name = "space-exploration-b",
    group = "space-exploration",
    order = "b",
    },
    {
    type = "item-subgroup",
    name = "space-exploration-c",
    group = "space-exploration",
    order = "c",
    },
    {
    type = "item-subgroup",
    name = "space-exploration-d",
    group = "space-exploration",
    order = "d",
    },
    {
    type = "item-subgroup",
    name = "space-exploration-x",
    group = "space-exploration",
    order = "x",
    },
    {
    type = "item-subgroup",
    name = "space-exploration-y",
    group = "space-exploration",
    order = "y",
    },
})

function allow_productivity(recipe_name)
  for _, prototype in pairs(data.raw["module"]) do
    if prototype.limitation and string.find(prototype.name, "productivity", 1, true) then
      table.insert(prototype.limitation, recipe_name)
    end
  end
end
allow_productivity("rocket-component")

--Setup the Rocket Silo to be compatible with the new payloads
data.raw["item"]["satellite"].rocket_launch_product = nil
data.raw["rocket-silo"]["rocket-silo"].fixed_recipe = "rocket-part"
data.raw["rocket-silo"]["rocket-silo"].rocket_parts_required = 100
data.raw["rocket-silo"]["rocket-silo"].hide_alt_info = true
data.raw["rocket-silo"]["rocket-silo"].rocket_result_inventory_size = 2

-- data.raw.recipe["rocket-part"].ingredients = {{"rocket-fuel",10}}
local rocket_fluid_box = 
    {
    production_type="input", 
    pipe_covers = pipecoverspictures(), 
    base_level = -1, 
    pipe_connections = {{position={0,5.5}}},
    }
data.raw["rocket-silo"]["rocket-silo"].fluid_boxes =  {rocket_fluid_box}
data.raw.recipe["rocket-part"].ingredients = {{type="fluid",name="light-oil",amount=10}}
data.raw.recipe["rocket-part"].energy_required = 1

function make_rocket(rocketName,rocketTier, rocketIngredients,rocketResults) 
    local item = {
    type = "item",
    name = rocketName,
    --icon = "__OberRocketry__/graphics/"..rocketName.."-item.png",
    icon = "__OberRocketry__/graphics/vanilla-rocket-item.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    subgroup = "space-exploration-"..rocketTier,
    order = rocketTier,
    stack_size = 1,
    rocket_launch_products = rocketResults
    }
    local recipe = {
    type = "recipe",
    name = rocketName,
    energy_required = 20,
    enabled = true,
    category = "crafting",
    ingredients = rocketIngredients,
    result = rocketName,
    }
    data:extend({item,recipe})
end
--Rocket Building

make_rocket("crude-rocket","b",
    {{"rocket",20},{"radar",2},{"electronic-circuit",20}},
    {{"space-science-pack",1}})
    
make_rocket("military-rocket","c",
    {{"rocket",40},{"artillery-shell",10},{"speed-module-2",1}},
    {{"space-science-pack",10}})
    
make_rocket("vanilla-rocket","d",
    {{"rocket-component",100},{"satellite",1}},
    {{"space-science-pack",1000},{"rocket-component",50}})
data.raw.item["satellite"].subgroup = "space-exploration-d"





data.raw.item["rocket-fuel"].subgroup = "space-exploration-a"
data.raw.item["low-density-structure"].subgroup = "space-exploration-a"
data.raw.item["rocket-control-unit"].subgroup = "space-exploration-a"
if mods.SpaceMod then
    data.raw.item["assembly-robot"].subgroup = "space-exploration-x"
    data.raw.item["drydock-assembly"].subgroup = "space-exploration-x"
    data.raw.item["drydock-structural"].subgroup = "space-exploration-x"
    data.raw.item["fusion-reactor"].subgroup = "space-exploration-y"
    data.raw.item["hull-component"].subgroup = "space-exploration-y"
    data.raw.item["protection-field"].subgroup = "space-exploration-y"
    data.raw.item["space-thruster"].subgroup = "space-exploration-y"
    data.raw.item["fuel-cell"].subgroup = "space-exploration-y"
    data.raw.item["habitation"].subgroup = "space-exploration-y"
    data.raw.item["life-support"].subgroup = "space-exploration-y"
    data.raw.item["command"].subgroup = "space-exploration-y"
    data.raw.item["astrometrics"].subgroup = "space-exploration-y"
    data.raw.item["ftl-drive"].subgroup = "space-exploration-y"
    data.raw.item["spacex-combinator"].subgroup = "space-exploration-x"
end

data:extend({
    {
    type = "item",
    name = "rocket-component",
    icon = "__base__/graphics/icons/rocket-part.png",
    icon_size = 32,
    flags = {"goes-to-main-inventory"},
    subgroup = "space-exploration-d",
    order = "a[rocket-component]",
    stack_size = 100
    },      
    {
    type = "recipe",
    name = "rocket-component",
    energy_required = 3,
    enabled = true,
    category = "crafting",
    ingredients =
    {
      {"rocket-control-unit", 10},
      {"low-density-structure", 10},
      {"rocket-fuel", 10}
    },
    result= "rocket-component"
    }
})