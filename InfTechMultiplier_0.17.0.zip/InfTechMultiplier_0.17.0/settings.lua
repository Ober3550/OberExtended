data:extend({
   {
      type = "double-setting",
      name = "inf-tech-mult",
      setting_type = "startup",
      default_value = 0.1,
   },
})