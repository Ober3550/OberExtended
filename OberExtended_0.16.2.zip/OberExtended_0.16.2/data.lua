data:extend({
        {
        type = "technology",
        name = "worker-robots-storage-5",
        icon = "__base__/graphics/technology/worker-robots-storage.png",
        icon_size = 128,
        effects = 
        {
            {
                type = "worker-robot-storage",
                modifier = 1,
            }
        },
        prerequisites = {"worker-robots-storage-3"},
        unit = 
        {
            --~64 Rockets required
            count_formula = "2^(L-5)*1000",
            ingredients =
            {
                {"science-pack-1", 1},
                {"science-pack-2", 1},
                {"science-pack-3", 1},
                {"production-science-pack", 1},
                {"high-tech-science-pack", 1},
                {"space-science-pack", 1}
            },
            time = 60,
        },
        upgrade = true,
        max_level = "10",
        order = "c-k-g-e"
    },
    {
    type = "technology",
    name = "inserter-capacity-bonus-8",
    icon = "__base__/graphics/technology/inserter-capacity.png",
    icon_size = 128,
    effects =
    {
        {
            type = "stack-inserter-capacity-bonus",
            modifier = 2
        }
    },
    prerequisites = {"inserter-capacity-bonus-7"},
    unit =
    {
        count_formula = "2^(L-8)*1000",
        ingredients =
        {
            {"science-pack-1", 1},
            {"science-pack-2", 1},
            {"science-pack-3", 1},
            {"production-science-pack", 1},
            {"high-tech-science-pack", 1},
            {"space-science-pack", 1}
        },
        time = 30
    },
    max_level = "11",
    upgrade = true,
    order = "c-o-i"
    },
})
data.raw.module["productivity-module-3"].effect =   
{
    productivity = {bonus = 0.1001}, 
    consumption = {bonus = 0.4},
    speed = {bonus = -0.15},
    pollution = {bonus = 0.5},
}
