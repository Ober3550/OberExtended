if mods["Long Inserters"] then
data.raw.recipe["long-fast-inserter"].hidden = true
data.raw.recipe["long-burner-inserter"].hidden = true
data.raw.recipe["long-filter-inserter"].hidden = true
table.remove(data.raw["technology"]["automation"].effects, 3)
table.remove(data.raw["technology"]["logistics"].effects, 4)
table.remove(data.raw["technology"]["electronics"].effects, 2)
--Aesthetic Swap
table.remove(data.raw["technology"]["stack-inserter"].effects, 3)
table.insert(data.raw["technology"]["stack-inserter"].effects, 
    {
        type = "stack-inserter-capacity-bonus",
        modifier = 1
    })
end