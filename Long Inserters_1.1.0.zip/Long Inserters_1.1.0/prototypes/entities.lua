local arm_colour = settings.startup["long-inserters-arm-colour"].value

longfast = util.table.deepcopy(data.raw["inserter"]["long-handed-inserter"])
longfast.name = "long-fast-inserter"
longfast.icon = "__Long Inserters__/graphics/icons/long-fast-inserter.png"
longfast.minable.result = "long-fast-inserter"
longfast.energy_per_movement = data.raw["inserter"]["fast-inserter"].energy_per_movement
longfast.energy_per_rotation = data.raw["inserter"]["fast-inserter"].energy_per_rotation
longfast.rotation_speed = data.raw["inserter"]["fast-inserter"].rotation_speed
longfast.extension_speed = data.raw["inserter"]["fast-inserter"].extension_speed
if arm_colour then
  longfast.hand_base_picture = data.raw["inserter"]["fast-inserter"].hand_base_picture
end
longfast.hand_closed_picture = data.raw["inserter"]["fast-inserter"].hand_closed_picture
longfast.hand_open_picture = data.raw["inserter"]["fast-inserter"].hand_open_picture

longburner = util.table.deepcopy(data.raw["inserter"]["long-handed-inserter"])
longburner.name = "long-burner-inserter"
longburner.icon = "__Long Inserters__/graphics/icons/long-burner-inserter.png"
longburner.minable.result = "long-burner-inserter"
longburner.energy_source = data.raw["inserter"]["burner-inserter"].energy_source
longburner.energy_per_movement = data.raw["inserter"]["burner-inserter"].energy_per_movement
longburner.energy_per_rotation = data.raw["inserter"]["burner-inserter"].energy_per_rotation
longburner.rotation_speed = data.raw["inserter"]["burner-inserter"].rotation_speed
longburner.extension_speed = data.raw["inserter"]["burner-inserter"].extension_speed
if arm_colour then
  longburner.hand_base_picture = data.raw["inserter"]["burner-inserter"].hand_base_picture
end
longburner.hand_closed_picture = data.raw["inserter"]["burner-inserter"].hand_closed_picture
longburner.hand_open_picture = data.raw["inserter"]["burner-inserter"].hand_open_picture

longfilter = util.table.deepcopy(data.raw["inserter"]["long-handed-inserter"])
longfilter.name = "long-filter-inserter"
longfilter.icon = "__Long Inserters__/graphics/icons/long-filter-inserter.png"
longfilter.minable.result = "long-filter-inserter"
longfilter.energy_per_movement = data.raw["inserter"]["filter-inserter"].energy_per_movement
longfilter.energy_per_rotation = data.raw["inserter"]["filter-inserter"].energy_per_rotation
longfilter.rotation_speed = data.raw["inserter"]["filter-inserter"].rotation_speed
longfilter.extension_speed = data.raw["inserter"]["filter-inserter"].extension_speed
longfilter.filter_count = data.raw["inserter"]["filter-inserter"].filter_count
if arm_colour then
  longfilter.hand_base_picture = data.raw["inserter"]["filter-inserter"].hand_base_picture
end
longfilter.hand_closed_picture = data.raw["inserter"]["filter-inserter"].hand_closed_picture
longfilter.hand_open_picture = data.raw["inserter"]["filter-inserter"].hand_open_picture

longstack = util.table.deepcopy(data.raw["inserter"]["long-handed-inserter"])
longstack.name = "long-stack-inserter"
longstack.icon = "__Long Inserters__/graphics/icons/long-stack-inserter.png"
longstack.stack = true
longstack.minable.result = "long-stack-inserter"
longstack.energy_per_movement = data.raw["inserter"]["stack-inserter"].energy_per_movement
longstack.energy_per_rotation = data.raw["inserter"]["stack-inserter"].energy_per_rotation
longstack.rotation_speed = data.raw["inserter"]["stack-inserter"].rotation_speed
longstack.extension_speed = data.raw["inserter"]["stack-inserter"].extension_speed
if arm_colour then
  longstack.hand_base_picture = data.raw["inserter"]["stack-inserter"].hand_base_picture
end
longstack.hand_closed_picture = data.raw["inserter"]["stack-inserter"].hand_closed_picture
longstack.hand_open_picture = data.raw["inserter"]["stack-inserter"].hand_open_picture

longstackfilter = util.table.deepcopy(data.raw["inserter"]["long-handed-inserter"])
longstackfilter.name = "long-stack-filter-inserter"
longstackfilter.icon = "__Long Inserters__/graphics/icons/long-stack-filter-inserter.png"
longstackfilter.stack = true
longstackfilter.minable.result = "long-stack-filter-inserter"
longstackfilter.energy_per_movement = data.raw["inserter"]["stack-filter-inserter"].energy_per_movement
longstackfilter.energy_per_rotation = data.raw["inserter"]["stack-filter-inserter"].energy_per_rotation
longstackfilter.rotation_speed = data.raw["inserter"]["stack-filter-inserter"].rotation_speed
longstackfilter.extension_speed = data.raw["inserter"]["stack-filter-inserter"].extension_speed
longstackfilter.filter_count = data.raw["inserter"]["stack-filter-inserter"].filter_count
if arm_colour then
  longstackfilter.hand_base_picture = data.raw["inserter"]["stack-filter-inserter"].hand_base_picture
end
longstackfilter.hand_closed_picture = data.raw["inserter"]["stack-filter-inserter"].hand_closed_picture
longstackfilter.hand_open_picture = data.raw["inserter"]["stack-filter-inserter"].hand_open_picture

data:extend({
  longfast,
  longburner,
  longfilter,
  longstack,
  longstackfilter
})