data:extend({
  {
    type = "recipe",
    name = "long-fast-inserter",
    enabled = false,
    ingredients =
    {
      {"fast-inserter", 1},
      {"long-handed-inserter", 1}
    },
    result = "long-fast-inserter",
    requester_paste_multiplier = 4
  },
  {
    type = "recipe",
    name = "long-burner-inserter",
    enabled = false,
    ingredients =
    {
      {"burner-inserter", 1},
      {"long-handed-inserter", 1}
    },
    result = "long-burner-inserter",
    requester_paste_multiplier = 4
  },
  {
    type = "recipe",
    name = "long-filter-inserter",
    enabled = false,
    ingredients =
    {
      {"filter-inserter", 1},
      {"long-handed-inserter", 1}
    },
    result = "long-filter-inserter",
    requester_paste_multiplier = 4
  },
  {
    type = "recipe",
    name = "long-stack-inserter",
    enabled = false,
    ingredients =
    {
      {"stack-inserter", 1},
      {"long-handed-inserter", 1}
    },
    result = "long-stack-inserter",
    requester_paste_multiplier = 4
  },
  {
    type = "recipe",
    name = "long-stack-filter-inserter",
    enabled = false,
    ingredients =
    {
      {"stack-filter-inserter", 1},
      {"long-handed-inserter", 1}
    },
    result = "long-stack-filter-inserter",
    requester_paste_multiplier = 4
  }
})