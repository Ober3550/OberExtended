table.insert(
  data.raw["technology"]["automation"].effects,
  {type = "unlock-recipe",recipe = "long-burner-inserter"})
table.insert(
  data.raw["technology"]["logistics"].effects,
  {type = "unlock-recipe",recipe = "long-fast-inserter"})
table.insert(
  data.raw["technology"]["electronics"].effects,
  {type = "unlock-recipe",recipe = "long-filter-inserter"})
table.insert(
  data.raw["technology"]["stack-inserter"].effects,
  {type = "unlock-recipe",recipe = "long-stack-inserter"})
table.insert(
  data.raw["technology"]["stack-inserter"].effects,
  {type = "unlock-recipe",recipe = "long-stack-filter-inserter"})