data:extend({
	{
		type = "bool-setting",
		name = "long-inserters-arm-colour",
		setting_type = "startup",
		default_value = true
	}
})