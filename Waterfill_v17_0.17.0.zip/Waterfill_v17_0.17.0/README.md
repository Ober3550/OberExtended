# waterfill

Factorio mod
 
This mod allows the placement of water just like landfill.

Research the tech to unlock.

All credits go to ceryss & Riley19280 - I just updated their mod for version 0.17, if they update their mod i will remove this.

-----------
Update 0.17.0 
- Fixed Science packs.
- Upgraded to 0.17
