--Nuclear Furnace
local nuclear_furnace = table.deepcopy(data.raw.furnace["electric-furnace"])
local furnace_internal = table.deepcopy(data.raw.boiler["heat-exchanger"])
nuclear_furnace.name = "nuclear-furnace"
nuclear_furnace.energy_source = furnace_internal.energy_source
nuclear_furnace.max_health = 500
nuclear_furnace.energy_usage = "360kW"
nuclear_furnace.minable = {mining_time = 1, result = "nuclear-furnace"}
nuclear_furnace.target_temperature = 600
nuclear_furnace.crafting_categories = {"nuclear-smelting"}
nuclear_furnace.energy_source.connections =
    {
        {
          position = {0, -1},
          direction = defines.direction.north
        },
        {
          position = {0, 1},
          direction = defines.direction.south
        }
    }
table.insert(data.raw.recipe["heat-exchanger"].ingredients,{"boiler",1})
table.insert(data.raw.recipe["steam-turbine"].ingredients,{"steam-engine",1})
data.raw.recipe["electric-furnace"].ingredients = {
    {"steel-furnace",1},
    {"advanced-circuit",5},
    {"steel-plate",4}
}
data:extend({
    {
        type = "recipe-category",
        name = "nuclear-smelting",
    },
    {
        type = "recipe",
        name = "nuclear-smelting-copper-plate",
        category = "nuclear-smelting",
        energy_required = 10.5,
        enabled = false,
        ingredients = {{ "copper-ore", 2}},
        result = "copper-plate",
        result_count = 3,
    },
    {
        type = "recipe",
        name = "nuclear-smelting-iron-plate",
        category = "nuclear-smelting",
        energy_required = 10.5,
        enabled = false,
        ingredients = {{"iron-ore", 2}},
        result = "iron-plate",
        result_count = 3,
    },
    {
        type = "recipe",
        name = "nuclear-smelting-stone-brick",
        category = "nuclear-smelting",
        energy_required = 10.5,
        enabled = false,
        ingredients = {{"stone", 4}},
        result = "stone-brick",
        result_count = 3,
    },
    {
        type = "recipe",
        name = "nuclear-smelting-steel-plate",
        category = "nuclear-smelting",
        normal =
        {
        enabled = false,
        energy_required = 52.5,
        ingredients = {{"iron-plate", 10}},
        result = "steel-plate",
        result_count = 3,
        },
        expensive =
        {
        enabled = false,
        energy_required = 105,
        ingredients = {{"iron-plate", 20}},
        result = "steel-plate",
        result_count = 3,
        },
    },
    nuclear_furnace,
    {
        type = "item",
        name = "nuclear-furnace",
        icon = "__base__/graphics/icons/electric-furnace.png",
        icon_size = 32,
        flags = {"goes-to-quickbar"},
        subgroup = "smelting-machine",
        order = "c[nuclear-furnace]",
        place_result = "nuclear-furnace",
        stack_size = 50
    },
    {
        type = "recipe",
        name = "ober-nuclear-furnace",
        ingredients = {
            {"electric-furnace",1},
            {"processing-unit",20},
            {"refined-concrete",50},
        },
        subgroup = "smelting-machine",
        order = "d[nuclear-furnace]",
        result = "nuclear-furnace",
        energy_required = 10,
        enabled = false,
    },
})