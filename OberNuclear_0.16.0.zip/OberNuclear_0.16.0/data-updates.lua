function nuclear_category(input,output)
    local newCategory = {}
    for recipeName,_ in pairs(data.raw["recipe"]) do
        local oldRecipe = table.deepcopy(data.raw.recipe[recipeName])
        if oldRecipe.category == "smelting" and oldRecipe.normal then
            local newRecipe = oldRecipe
            newRecipe.category = "nuclear-smelting"
            newRecipe.name = "nuclear-smelting-"..oldRecipe.name
            newRecipe.type = "recipe"
            newRecipe.normal.ingredients[1][2] = oldRecipe.normal.ingredients[1][2]*input
            newRecipe.normal.enabled = false
            newRecipe.normal.energy_required = oldRecipe.normal.energy_required*input
            if oldRecipe.normal.result_count then
                newRecipe.normal.result_count = output*oldRecipe.normal.result_count
            else
                newRecipe.normal.result_count = output
            end
            log(serpent.block(newRecipe))
            data:extend({newRecipe})
            table.insert(data.raw.technology["ober-nuclear-processing"].effects,{type="unlock-recipe",recipe = newRecipe.name})
        end
        if oldRecipe.category == "smelting" and oldRecipe.expensive then
            local newRecipe = oldRecipe
            newRecipe.category = "nuclear-smelting"
            newRecipe.name = "nuclear-smelting-"..oldRecipe.name
            newRecipe.type = "recipe"
            newRecipe.expensive.ingredients[1][2] = oldRecipe.expensive.ingredients[1][2]*input
            newRecipe.expensive.enabled = false
            newRecipe.expensive.energy_required = oldRecipe.expensive.energy_required*input
            if oldRecipe.expensive.result_count then
                newRecipe.expensive.result_count = output*oldRecipe.expensive.result_count
            else
                newRecipe.expensive.result_count = output
            end
            log(serpent.block(newRecipe))
            data:extend({newRecipe})
            table.insert(data.raw.technology["ober-nuclear-processing"].effects,{type="unlock-recipe",recipe = newRecipe.name})
        end
        if oldRecipe.category == "smelting" then
            local newRecipe = oldRecipe
            newRecipe.category = "nuclear-smelting"
            newRecipe.name = "nuclear-smelting-"..oldRecipe.name
            newRecipe.type = "recipe"
            newRecipe.ingredients[1][2] = oldRecipe.ingredients[1][2]*input
            newRecipe.enabled = false
            newRecipe.energy_required = oldRecipe.energy_required*input
            if oldRecipe.result_count then
                newRecipe.result_count = output*oldRecipe.result_count
            else
                newRecipe.result_count = output
            end
            log(serpent.block(newRecipe))
            data:extend({newRecipe})
            table.insert(data.raw.technology["ober-nuclear-processing"].effects,{type="unlock-recipe",recipe = newRecipe.name})
        end
    end
end
nuclear_category(3,4)