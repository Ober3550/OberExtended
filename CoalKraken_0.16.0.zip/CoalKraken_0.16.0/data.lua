data.raw.recipe["coal-liquefaction"].ingredients =
    {
      {type="item", name="coal", amount=10},
      {type="fluid", name="steam", amount=50}
    }
data.raw.recipe["coal-liquefaction"].results =
    {
      {type="fluid", name="heavy-oil", amount=30},
      {type="fluid", name="light-oil", amount=30},
      {type="fluid", name="petroleum-gas", amount=40}
    }
table.insert(data.raw.technology["oil-processing"].effects, 
{
    type = "unlock-recipe",
    recipe = "coal-liquefaction"
})
data.raw.technology["coal-liquefaction"] = nil